import java.util.Scanner;

class task_6{

	public static void main(String []args){
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the String");
		String name=input.nextLine();

		if(name.contains("Java"))
		{
			System.out.println("String contain with Java");
		}
		else
		{
			System.out.println("String does contain not Java");
		}
	}
}