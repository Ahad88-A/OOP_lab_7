import java.util.Scanner;

class task_5{

	public static void main(String []args)
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the String");
		String name=input.nextLine();

		if(name.endsWith("World"))
		{
			System.out.println("String Start with World");
		}
		else
		{
			System.out.println("String not start with World");
		}
	}
	}