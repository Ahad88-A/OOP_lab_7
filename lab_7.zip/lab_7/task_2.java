
	import java.util.Scanner;

class task_2{

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String check = input.nextLine();
        int index = check.indexOf("a");
        System.out.println("Index of first 'a': " + index);    
    }
   }