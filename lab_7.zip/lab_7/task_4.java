
import java.util.Scanner;

class task_4{

	public static void main(String [] args)
	{
		Scanner input=new Scanner(System.in);

		System.out.println("Enter the String");
		String name=input.nextLine();

		if(name.startsWith("Hello"))
		{
			Sytem.out.println("String Start with Hello");
		}
		else
		{
			System.out.println("String not start with Hello");
		}
	}
}