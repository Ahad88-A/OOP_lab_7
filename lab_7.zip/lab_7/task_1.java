
import java.util.Scanner;

class task_1{

	public static void main(String []args){
		Scanner input=new Scanner(System.in);

		System.out.println("Enter the String ");
		String check=input.nextLine();

		if(check.isEmpty())
		{
			System.out.println("String is Empty");
		}
		else
		{
			System.out.println("String is not Empty");
		}
	}
	}