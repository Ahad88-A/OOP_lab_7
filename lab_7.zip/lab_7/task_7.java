import java.util.Scanner;

class task_7{


	public static void main(String []args){
		Scanner input=new Scanner(System.in);

		System.out.println("Enter the String");
		String remove=input.nextLine();

		String modified=remove.replace(" ","");
		System.out.println("Replaced and modified :"+modified);
	}

}