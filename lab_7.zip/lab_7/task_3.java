 
 import java.util.Scanner;

class task_3{

    public static void main(String [] args)
    {
    	Scanner input =new Scanner(System.in);

    	System.out.println("Enter the names ");
    	String[] Array=new String[5];

    	for(int i=0;i<Array.length;i++)
    	{
    		Array[i]=input.nextLine();
    	}

    	System.out.println("Upper case");
    	for(int i=0;i<Array.length;i++)
    	{
    		System.out.println(Array[i].toUpperCase());
    	}
    }
}